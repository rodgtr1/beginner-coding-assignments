/******* MODAL *******/

if (document.getElementById("easter-egg")) {
    // Target Easter Egg Components
    let easterEgg = document.getElementById("easter-egg");
    let easterEggModal = document.getElementById("easter-egg-modal");
    let easterEggInput = document.getElementById("easter-egg-input");
    let easterEggModalClose = document.getElementsByClassName("close")[0];

    // Toggle Modal
    easterEgg.onclick = function() {
        if (easterEggModal.className === 'modal-hidden') {
            easterEggModal.className = 'modal-shown';
        } else {
        easterEggModal.className = 'modal-hidden';
        }
    }

    // Hide modal on X click
    easterEggModalClose.onclick = function() {
        easterEggModal.className = 'modal-hidden';
    }

    // Check for user input and alert if winner or loser
    easterEggInput.addEventListener('keyup', function(e){
        console.log(e.target.value);
        if (e.target.value == 39887) {
            alert('You\'re the winner! Report to Tim at the front desk with your code and receive the grand prize!');
        } else if (e.target.value != 39887 && e.target.value.length >= 5) {
            alert("Sorry, you're code is invalid");
            easterEggInput.value = '';
        }
    })
}

/******* COUNDOWN TIMER *******/

    // new Date() gets the current date. Running getTime() on the current date converts it to milliseconds, which you want to work in.
    
    // You want to get the final countdown time/date. 

    // You want to use JavaScript's setInterval method to run a function every second (or 1000 ms)

    // In that function you want to get the current time/date, compare it with the final coundown time/date, and put that in a variable. 

    // Then you need to do some millisecond conversions with your remaining time to put it back into "human" format. There is no magic here....just math. And it's this:
    //var days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
    //var hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    //var minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
    //var seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);

    // Then you want to use JavaScript to display that on your page. 

    // Finally, you want to be sure to change the message when the timer runs out. 

    // Final Coundown Time and Date
    let coundownDateTime = new Date("June 15, 2019 00:00:00").getTime();

    // Check time every second to compare to coundown date
    let timer = setInterval(function() {

    // Get todays date and time
    var currentDateTime = new Date().getTime();

    // Find the distance between now and the count down date
    var remainingTime = coundownDateTime - currentDateTime;

    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
    var hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);

    // Target coundown ID on homepage
    let countdown = document.getElementById("countdown");

    // Display the result in the element with id="countdown"
    if (countdown && remainingTime > 0) {
        countdown.innerHTML = "Time Remaining: " + days + "d " + hours + "h "
        + minutes + "m " + seconds + "s ";
    } else {
        countdown.innerHTML = "Conference is either in progress or over."
    }

}, 1000)

