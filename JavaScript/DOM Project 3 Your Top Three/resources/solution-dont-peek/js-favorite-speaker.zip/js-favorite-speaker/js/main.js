// Create new page called rating. Create buttons, a div for your 3 speakers, and a button. Style accordingly.

// Get elements by class name. When you do this you select them, and then you have to loop through them assigning an event listener to each, so when one is clicked the event info for that particular button is registered. 

// You want to add that speaker name to the div you created.

// You want to create an alert if it goes over 3. 

// Create a button click event to "submit" the data and replace the page with a Thank You Message. Be sure that the button works only if 3 names are listed. 















let ratingButtons = document.getElementsByClassName('rating-button');

var j = 0;
for (var i = 0; i < ratingButtons.length; i++) {
    ratingButtons[i].addEventListener("click", function(e) {
        let speakerName = e.target.innerHTML;
        let topSpeakers = document.getElementById('top-speakers');
        
        if (j >= 3) {
            console.log(j);
            alert('You can only choose three speakers');
            i = 2;
        } else if (j == 2) {
            topSpeakers.innerHTML += (speakerName + "<br>");
            let buttonClick = document.getElementById('rating-button');
            buttonClick.addEventListener('click', function(){
                let ratingApp = document.getElementById('rating-app');
                ratingApp.innerHTML = '<div class="success pulsate">Thank You</div>';
            })
            j++;
        } else {
            console.log(j);
            topSpeakers.innerHTML += (speakerName + "<br>");
            j++;
        }
    });
}